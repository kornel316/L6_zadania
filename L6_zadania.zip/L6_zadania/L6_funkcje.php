
<?php

// 1
function SUMA($a, $b) {
    echo $a + $b;
}

// 2
function PODSTAWY($a, $b) {
    echo "Różnica: " . ($a - $b) . "<br>";
    echo "Iloczyn: " . ($a * $b) . "<br>";

    if ($b != 0) {
        echo "Iloraz: " . ($a / $b) . "<br>";
    } else {
        echo "Nie można dzielić przez zero";
    }
}

// 3
function KALKULATOR($a, $b, $dzialanie) {
    switch ($dzialanie) {
        case "+":
            $wynik = $a + $b;
            break;
        case "-":
            $wynik = $a - $b;
            break;
        case "*":
            $wynik = $a * $b;
            break;
        case "/":
            if ($b == 0) {
                $wynik = "Nie można dzielić przez zero";
            } else {
                $wynik = $a / $b;
            }
            break;
        default:
            $wynik = "Nieznane działanie";
    }

    echo "<div id='wynik'>$wynik</div>";
}

// 4
function MAKS($a, $b, $c) {
    echo max($a, $b, $c);
}

// 5
function WZROST($wzrost) {
    if ($wzrost < 150) {
        echo "Niski";
    } elseif ($wzrost > 180) {
        echo "Wysoki";
    } else {
        echo "Średni";
    }
}

// 6
function BMI($wzrost, $waga) {
    if ($wzrost <= 0) {
        echo "Nieprawidłowy wzrost";
        return;
    }

    $bmi = $waga / (($wzrost / 100) ** 2);

    if ($bmi < 18.5) {
        $komentarz = "za mało!";
    } elseif ($bmi > 25) {
        $komentarz = "za dużo!";
    } else {
        $komentarz = "OK!";
    }

    echo "<div id='wynik'>";
    echo "BMI: " . round($bmi, 2) . " - " . $komentarz;
    echo "</div>";
}

// 7
function STARSZY($data1, $data2) {
    $osoba1 = new DateTime($data1);
    $osoba2 = new DateTime($data2);

    if ($osoba1 < $osoba2) {
        echo "Pierwsza osoba jest starsza";
    } elseif ($osoba1 > $osoba2) {
        echo "Druga osoba jest starsza";
    } else {
        echo "Osoby są w tym samym wieku";
    }
}

// 8
function PRZESTEPNY($rok) {
    if (($rok % 4 == 0 && $rok % 100 != 0) || $rok % 400 == 0) {
        echo "Rok przestępny";
    } else {
        echo "Rok nieprzestępny";
    }
}

// 9
function SILA($haslo) {
    $dlugosc = strlen($haslo);

    $cyfra = preg_match('/[0-9]/', $haslo);
    $duza = preg_match('/[A-Z]/', $haslo);
    $mala = preg_match('/[a-z]/', $haslo);
    $specjalny = preg_match('/[^a-zA-Z0-9]/', $haslo);

    if ($dlugosc <= 4 || !$cyfra || !$duza || !$mala || !$specjalny) {
        echo "Hasło słabe";
    } elseif ($dlugosc < 8) {
        echo "Hasło średnie";
    } else {
        echo "Hasło mocne";
    }
}

// 10
function TROJKAT($a, $b, $c) {
    if (
        $a > 0 && $b > 0 && $c > 0 &&
        $a + $b > $c &&
        $a + $c > $b &&
        $b + $c > $a
    ) {
        echo "Można utworzyć trójkąt";
    } else {
        echo "Nie można utworzyć trójkąta";
    }
}

// 11
function SZYFR() {
    echo "
    <script>
    document.getElementById('tekst').addEventListener('input', function() {
        let tekst = this.value;
        let szyfr = '';

        for (let i = 0; i < tekst.length; i++) {
            let znak = tekst[i];

            if (znak >= 'a' && znak <= 'z') {
                szyfr += String.fromCharCode(
                    (znak.charCodeAt(0) - 97 + 2) % 26 + 97
                );
            }
            else if (znak >= 'A' && znak <= 'Z') {
                szyfr += String.fromCharCode(
                    (znak.charCodeAt(0) - 65 + 2) % 26 + 65
                );
            }
            else {
                szyfr += znak;
            }
        }

        document.getElementById('wynikSzyfr').innerHTML = szyfr;
    });
    </script>
    ";
}

?>
