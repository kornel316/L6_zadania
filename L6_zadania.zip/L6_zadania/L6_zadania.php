
<?php
require_once "funkcje.php";
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania PHP</title>
</head>
<body>

<h2>1. SUMA</h2>
<?php
SUMA(5, 10);
?>

<br>

<h2>2. PODSTAWY</h2>
<?php
PODSTAWY(10, 5);
?>

<br>

<h2>3. KALKULATOR</h2>
<?php
KALKULATOR(10, 5, "+");
?>

<br>

<h2>4. MAKS</h2>
<?php
MAKS(5, 12, 8);
?>

<br>

<h2>5. WZROST</h2>
<?php
WZROST(175);
?>

<br>

<h2>6. BMI</h2>
<?php
BMI(180, 75);
?>

<br>

<h2>7. STARSZY</h2>
<?php
STARSZY("2000-05-10", "2005-03-20");
?>

<br>

<h2>8. PRZESTEPNY</h2>
<?php
PRZESTEPNY(2024);
?>

<br>

<h2>9. SILA</h2>
<?php
SILA("Test123!");
?>

<br>

<h2>10. TROJKAT</h2>
<?php
TROJKAT(3, 4, 5);
?>

<br>

<h2>11. SZYFR</h2>

<input type="text" id="tekst" placeholder="Wpisz tekst">

<p>
Zaszyfrowany tekst:
<span id="wynikSzyfr"></span>
</p>

<?php
SZYFR();
?>

</body>
</html>
